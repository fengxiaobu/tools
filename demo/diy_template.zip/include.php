<?php
// 注册插件
RegisterPlugin("default","ActivePlugin_default");
// 挂靠接口
function ActivePlugin_default() {
    Add_Filter_Plugin('Filter_Plugin_Edit_Response3','default_Article_Edit_Respons3');
}

/**
 * 取出模板信息，合法模板信息存储在数组中
 */
function default_LoadTemplate() {
    global $zbp;
    $array = array();
    // 匹配系统自带
    $array['index'] = array(
        'type'  => 'list',
        'name'  => '默认模板',
    );
    $array['single'] = array(
        'type'  => 'single',
        'name'  => '默认模板',
    );
    // 读取模板中的声明
    foreach ($zbp->templates as $key => $value) {
        preg_match_all('/\{\*\s*type\s*?\:\s*?\"([a-z,\d,_,-]+)\"\s*?name\s*?\:\s*?\"(.*?)\"\s*?\*\}/',$value,$temp);
        if (isset($temp[1][0])&&isset($temp[2][0])) {
            $array[$key] = array(
                'type' => $temp[1][0],
                'name' => $temp[2][0],
            );
        }
    }
    $zbp->Config('default')->template_diy = $array;
    $zbp->SaveConfig('default');
}

// 接入文章编辑页的3号接口
function default_Article_Edit_Respons3() {
    global $zbp,$article;
	default_Article_CustomMeta_Response3($article);
}
// 3号接口需要展示的内容
function default_Article_CustomMeta_Response3(&$object) {
    global $zbp;
    $type = (GetVars('act','GET')=='PageEdt')?'page':'article';
    echo
    '<div id=\'template2\' class="editmod"> <label for="cmbTemplate" class="editinputname" style="max-width:65px;text-overflow:ellipsis;">模板</label>
            <select style="width:180px;" class="edit" size="1" name="Template" id="cmbTemplate" onChange="edtTemplate.value=this.options[this.selectedIndex].value">';
	            default_create_template_select($object->Template,$type);
    echo   '</select>
    </div>';
    // 用js移除原有的下拉选择器
    echo '
        <script>
            $("#template").remove();
        </script>
    ';
}
/**
 * 生成模板的option选项
 * @param {string} $default 当前采用模板
 * @param {string} $type 生成对应类型 默认all全局 具体type参照规范
 */
function default_create_template_select($default,$type='all') {
    global $zbp;
    default_LoadTemplate();
    function judgeType($tempType,$reqType) {
        if ($tempType=='hide') {
            return false;
        }
        if ($tempType == $reqType || $tempType=='all') {
            return true;
        }
        if (($reqType == 'article'||$reqType=='page')&&$tempType=='single') {
            return true;
        }
        if (($reqType == 'category'||$reqType=='tag'||$reqType=='author')&&$tempType=='list') {
            return true;
        }
        return false;
    }
    $str = '';
	$str .= '<option value="" >' . $zbp->lang['msg']['none'] . '</option>'; // 无
    foreach ($zbp->Config('default')->template_diy as $key => $value) {
        if (judgeType($value['type'],$type)) {
            if ($default==$key) {
                $str .= '<option value="'.$key.'" selected="selected" >' . $value['name'] . '</option>';
            } else {
                $str .= '<option value="'.$key.'" >' . $value['name'] . '</option>';
            }
        }
    }
    echo $str;
}

function InstallPlugin_default(){
    global $zbp;
    if(!$zbp->Config('default')->HasKey('Version')){
        $array = array(
            'template_diy'                   =>  array(),
        );
        foreach ($array as $value => $intro) {
            $zbp->Config('default')->$value = $intro;
        }
    }
    $zbp->Config('default')->Version = '1.0';
    $zbp->SaveConfig('default');
}

function UninstallPlugin_default(){
    global $zbp;
    $zbp->DelConfig('default');
}

?>
