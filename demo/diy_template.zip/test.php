{*
type : "article"
name : "测试模板"
*}

{php}
 // 规范定义
 // type 类型(英文)   用于区分模板类型    all全部可用|hide全部隐藏|single文章与单页通用|article文章|page单页|list列表页通用|category分类|tagTag标签|author用户页
 // name 名称(中文|英文等)
{/php}
